-- Business Brain AI: function to record a sale and reduce stock atomically.
-- Matches the existing schema: bigint IDs; products.quantity/cost/price/currency;
-- sales.customer_id/product_id/product_name/quantity/unit_price/total/cost_total/currency.
-- Run once in Supabase > SQL Editor.

create or replace function public.record_sale(
  p_product_id bigint,
  p_quantity numeric,
  p_customer_id bigint default null
) returns void
language plpgsql
security invoker
set search_path = public
as $$
declare
  p public.products%rowtype;
begin
  if p_quantity <= 0 then
    raise exception 'Quantity must be positive';
  end if;

  select * into p
  from public.products
  where id = p_product_id and owner_id = auth.uid()
  for update;

  if not found then
    raise exception 'Product not found';
  end if;

  if p.quantity < p_quantity then
    raise exception 'Insufficient stock';
  end if;

  if p_customer_id is not null and not exists (
    select 1 from public.customers
    where id = p_customer_id and owner_id = auth.uid()
  ) then
    raise exception 'Customer not found';
  end if;

  update public.products
  set quantity = quantity - p_quantity
  where id = p_product_id and owner_id = auth.uid();

  insert into public.sales (
    owner_id, product_id, customer_id, product_name,
    quantity, unit_price, total, cost_total, currency
  ) values (
    auth.uid(), p.id, p_customer_id, p.name,
    p_quantity, p.price, p.price * p_quantity,
    p.cost * p_quantity, p.currency
  );
end;
$$;

revoke all on function public.record_sale(bigint, numeric, bigint) from public;
grant execute on function public.record_sale(bigint, numeric, bigint) to authenticated;
grant select, insert, update, delete on public.products to authenticated;
grant select, insert, update, delete on public.customers to authenticated;
grant select, insert, update, delete on public.sales to authenticated;
